<?php

return [
    'admin_email'   => 'mail@mail.ru',
    'fwcms_name'    => 'fwcms',
    'pagination'    => 3,
    'smtp_login'    => '',
    'smtp_password' => '',
];